import { useState } from 'react';
import { Card, Select, Button, DatePicker, Radio, message, Typography } from 'antd';
import { FileTextOutlined, FilePdfOutlined, FileExcelOutlined } from '@ant-design/icons';
import { rapportService } from '../../services';
import dayjs from 'dayjs';

const { Option } = Select;
const { Title } = Typography;

const currentYear = new Date().getFullYear();
const currentMonth = new Date().getMonth() + 1;

function Rapports() {
  const [loading, setLoading] = useState(false);
  const [config, setConfig] = useState({
    type: 'pointages',
    format: 'pdf',
    mois: currentMonth,
    annee: currentYear,
  });

  const handleGenerer = async () => {
    try {
      setLoading(true);
      let response;

      if (config.type === 'pointages') {
        if (config.format === 'pdf') {
          response = await rapportService.pointagesPDF(config.mois, config.annee);
        } else {
          response = await rapportService.pointagesExcel(config.mois, config.annee);
        }
      } else {
        if (config.format === 'pdf') {
          response = await rapportService.salairesPDF(config.mois, config.annee);
        } else {
          response = await rapportService.salairesExcel(config.mois, config.annee);
        }
      }

      // Créer un blob et déclencher le téléchargement
      const blob = new Blob([response.data], {
        type: config.format === 'pdf' ? 'application/pdf' : 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
      });
      
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      
      const filename = `${config.type}_${config.mois}_${config.annee}.${config.format}`;
      link.setAttribute('download', filename);
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.URL.revokeObjectURL(url);

      message.success('Rapport généré avec succès');
    } catch (error) {
      message.error('Erreur lors de la génération du rapport');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <Title level={2}>
        <FileTextOutlined /> Génération de Rapports
      </Title>

      <Card style={{ maxWidth: 600 }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 24 }}>
          <div>
            <label style={{ display: 'block', marginBottom: 8, fontWeight: 'bold' }}>
              Type de rapport
            </label>
            <Radio.Group
              value={config.type}
              onChange={(e) => setConfig({ ...config, type: e.target.value })}
              buttonStyle="solid"
            >
              <Radio.Button value="pointages">Pointages</Radio.Button>
              <Radio.Button value="salaires">Salaires</Radio.Button>
            </Radio.Group>
          </div>

          <div>
            <label style={{ display: 'block', marginBottom: 8, fontWeight: 'bold' }}>
              Format
            </label>
            <Radio.Group
              value={config.format}
              onChange={(e) => setConfig({ ...config, format: e.target.value })}
              buttonStyle="solid"
            >
              <Radio.Button value="pdf">
                <FilePdfOutlined /> PDF
              </Radio.Button>
              <Radio.Button value="excel">
                <FileExcelOutlined /> Excel
              </Radio.Button>
            </Radio.Group>
          </div>

          <div>
            <label style={{ display: 'block', marginBottom: 8, fontWeight: 'bold' }}>
              Période
            </label>
            <div style={{ display: 'flex', gap: 16 }}>
              <Select
                value={config.mois}
                style={{ width: 200 }}
                onChange={(value) => setConfig({ ...config, mois: value })}
              >
                {[...Array(12)].map((_, i) => (
                  <Option key={i + 1} value={i + 1}>
                    {new Date(2000, i).toLocaleString('fr-FR', { month: 'long' })}
                  </Option>
                ))}
              </Select>
              <Select
                value={config.annee}
                style={{ width: 120 }}
                onChange={(value) => setConfig({ ...config, annee: value })}
              >
                {[currentYear - 1, currentYear, currentYear + 1].map(year => (
                  <Option key={year} value={year}>{year}</Option>
                ))}
              </Select>
            </div>
          </div>

          <Button
            type="primary"
            size="large"
            icon={<FileTextOutlined />}
            onClick={handleGenerer}
            loading={loading}
            style={{ marginTop: 16 }}
          >
            Générer le Rapport
          </Button>
        </div>
      </Card>

      <Card style={{ marginTop: 24, maxWidth: 600 }}>
        <Title level={4}>Informations</Title>
        <ul>
          <li><strong>Rapport Pointages:</strong> Génère un rapport détaillé des présences par employé avec totaux</li>
          <li><strong>Rapport Salaires:</strong> Génère les bulletins de paie détaillés avec tous les calculs</li>
          <li><strong>Format PDF:</strong> Document imprimable et partage facile</li>
          <li><strong>Format Excel:</strong> Données exploitables pour analyse supplémentaire</li>
        </ul>
      </Card>
    </div>
  );
}

export default Rapports;
