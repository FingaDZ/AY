﻿# AY HR Management v1.1.4 - Package Windows

## Installation Rapide

1. Extraire ce fichier ZIP dans un dossier de votre choix
2. Ouvrir PowerShell en tant qu'Administrateur
3. Naviguer vers le dossier extrait:
   ```
   cd "C:\chemin\vers\ay-hr-v1.1.4-windows"
   ```
4. ExÃ©cuter le script d'installation:
   ```
   .\install-windows.ps1
   ```

## Contenu du Package

- **backend/** - Code source du serveur API
- **frontend/** - Code source de l'interface web
- **database/** - Scripts SQL de crÃ©ation de la base de donnÃ©es
- **install-windows.ps1** - Script d'installation automatique
- **start-windows.ps1** - Script de dÃ©marrage manuel
- **stop-windows.ps1** - Script d'arrÃªt
- **install-service-windows.ps1** - Installation en tant que service Windows
- **INSTALLATION_GUIDE.md** - Guide d'installation complet

## PrÃ©requis

- Windows 10/11 ou Windows Server 2016+
- Python 3.11 ou supÃ©rieur
- Node.js 18 ou supÃ©rieur
- MariaDB 10.11 ou supÃ©rieur

## Documentation

Consultez le fichier **INSTALLATION_GUIDE.md** pour:
- Instructions d'installation dÃ©taillÃ©es
- Configuration de la base de donnÃ©es
- DÃ©pannage
- Configuration rÃ©seau
- ProcÃ©dures de sauvegarde

## Support

Pour toute question ou problÃ¨me:
- Consultez INSTALLATION_GUIDE.md section "DÃ©pannage"
- VÃ©rifiez les logs dans le dossier logs/
- Contactez votre administrateur systÃ¨me

## Version

Version: 1.1.4
Date: 14/11/2025
