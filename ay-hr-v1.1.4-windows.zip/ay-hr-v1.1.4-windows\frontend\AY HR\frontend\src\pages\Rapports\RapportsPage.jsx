import { useState } from 'react';
import { Card, Row, Col, Button, DatePicker, message, Divider, Space, Typography } from 'antd';
import {
  FileTextOutlined,
  TeamOutlined,
  ClockCircleOutlined,
  UserOutlined,
  DollarOutlined,
  CalculatorOutlined,
  DownloadOutlined
} from '@ant-design/icons';
import { employeService, pointageService, clientService, avanceService, salaireService } from '../../services';
import dayjs from 'dayjs';
import 'dayjs/locale/fr';

const { Title, Paragraph } = Typography;
const { MonthPicker } = DatePicker;

dayjs.locale('fr');

function RapportsPage() {
  const [loading, setLoading] = useState(false);
  const [selectedPeriod, setSelectedPeriod] = useState(dayjs());

  const handleDownloadRapport = async (type, endpoint, filename) => {
    try {
      setLoading(true);
      let response;
      
      const annee = selectedPeriod.year();
      const mois = selectedPeriod.month() + 1;

      switch (type) {
        case 'employes':
          response = await employeService.getRapportActifs(annee, mois);
          break;
        case 'pointages':
          response = await pointageService.getRapportMensuel(annee, mois);
          break;
        case 'clients':
          response = await clientService.getRapportListe();
          break;
        case 'avances':
          response = await avanceService.getRapportMensuel(annee, mois);
          break;
        case 'salaires':
          response = await salaireService.genererRapport({ annee, mois });
          break;
        default:
          throw new Error('Type de rapport inconnu');
      }

      // Créer un lien de téléchargement
      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', filename || 'rapport.pdf');
      document.body.appendChild(link);
      link.click();
      link.remove();

      message.success('Rapport téléchargé avec succès');
    } catch (error) {
      message.error(error.response?.data?.detail || 'Erreur lors de la génération du rapport');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const rapportCards = [
    {
      title: 'Employés Actifs',
      description: 'Liste des employés actifs par période',
      icon: <TeamOutlined style={{ fontSize: 32, color: '#1890ff' }} />,
      color: '#e6f7ff',
      type: 'employes',
      filename: `employes_actifs_${selectedPeriod.format('MM_YYYY')}.pdf`,
      needsPeriod: true
    },
    {
      title: 'Pointages Mensuels',
      description: 'Rapport des pointages du mois sélectionné',
      icon: <ClockCircleOutlined style={{ fontSize: 32, color: '#52c41a' }} />,
      color: '#f6ffed',
      type: 'pointages',
      filename: `pointages_${selectedPeriod.format('MM_YYYY')}.pdf`,
      needsPeriod: true
    },
    {
      title: 'Liste des Clients',
      description: 'Tous les clients enregistrés',
      icon: <UserOutlined style={{ fontSize: 32, color: '#fa8c16' }} />,
      color: '#fff7e6',
      type: 'clients',
      filename: 'clients.pdf',
      needsPeriod: false
    },
    {
      title: 'Avances du Mois',
      description: 'Rapport des avances par mois',
      icon: <DollarOutlined style={{ fontSize: 32, color: '#eb2f96' }} />,
      color: '#fff0f6',
      type: 'avances',
      filename: `avances_${selectedPeriod.format('MM_YYYY')}.pdf`,
      needsPeriod: true
    },
    {
      title: 'Salaires Détaillés',
      description: 'Rapport complet des salaires',
      icon: <CalculatorOutlined style={{ fontSize: 32, color: '#722ed1' }} />,
      color: '#f9f0ff',
      type: 'salaires',
      filename: `rapport_salaires_${selectedPeriod.format('MM_YYYY')}.pdf`,
      needsPeriod: true
    }
  ];

  return (
    <div style={{ padding: '24px' }}>
      <Card>
        <Title level={2}>
          <FileTextOutlined /> Centre de Rapports
        </Title>
        <Paragraph>
          Générez et téléchargez tous vos rapports en un seul endroit. 
          Sélectionnez une période pour les rapports mensuels.
        </Paragraph>
        
        <Divider />

        <Space direction="vertical" size="large" style={{ width: '100%' }}>
          <Card size="small" style={{ backgroundColor: '#fafafa' }}>
            <Space>
              <strong>Période sélectionnée:</strong>
              <MonthPicker
                value={selectedPeriod}
                onChange={(date) => setSelectedPeriod(date || dayjs())}
                format="MMMM YYYY"
                placeholder="Sélectionner un mois"
                style={{ width: 200 }}
              />
            </Space>
          </Card>

          <Row gutter={[16, 16]}>
            {rapportCards.map((rapport) => (
              <Col xs={24} sm={12} lg={8} key={rapport.type}>
                <Card
                  hoverable
                  style={{
                    height: '100%',
                    backgroundColor: rapport.color,
                    borderColor: rapport.icon.props.style.color
                  }}
                >
                  <Space direction="vertical" size="middle" style={{ width: '100%' }}>
                    <div style={{ textAlign: 'center' }}>
                      {rapport.icon}
                    </div>
                    <Title level={4} style={{ margin: 0, textAlign: 'center' }}>
                      {rapport.title}
                    </Title>
                    <Paragraph style={{ textAlign: 'center', marginBottom: 16 }}>
                      {rapport.description}
                    </Paragraph>
                    <Button
                      type="primary"
                      icon={<DownloadOutlined />}
                      loading={loading}
                      block
                      onClick={() => handleDownloadRapport(
                        rapport.type,
                        null,
                        rapport.filename
                      )}
                    >
                      Télécharger PDF
                    </Button>
                    {rapport.needsPeriod && (
                      <div style={{ textAlign: 'center', fontSize: 12, color: '#888' }}>
                        Période: {selectedPeriod.format('MMMM YYYY')}
                      </div>
                    )}
                  </Space>
                </Card>
              </Col>
            ))}
          </Row>
        </Space>
      </Card>
    </div>
  );
}

export default RapportsPage;
